<?php

namespace Bigcommerce\Api;

/**
 * Raised if a network fault occurs.
 */
class NetworkError extends Error
{
}
